import React, { useState, useEffect } from 'react';

const Title = (props) => {
  return (
    <div id='titlebar'>
      <h1>Octave</h1>
    </div>
  );
};

export default Title;
