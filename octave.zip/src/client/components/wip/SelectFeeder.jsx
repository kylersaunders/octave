import React, { useState, useEffect, useId } from 'react';

const SelectFeeder = (props) => {
  return <>test text</>;
};

export default SelectFeeder;
