import React, { useState, useEffect } from 'react';

export default (props) => {
  return (
    <>
      <h2>Your Account:</h2>
    </>
  );
};
