import React, { useState, useEffect } from 'react';

export default (props) => {
  return (
    <>
      <h2>My Saved Workouts</h2>
    </>
  );
};
